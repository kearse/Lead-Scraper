"""
Business Search Engine - Discovers businesses based on search parameters.

NOTE: Current implementations are placeholders returning mock data.
Replace with real API / scraping logic (Google Places, Yelp Fusion, etc.).
"""
import asyncio
from typing import List, Dict, Optional
from dataclasses import dataclass
from utils.logger import setup_logger
from utils.rate_limiter import RateLimiter

logger = setup_logger(__name__)


@dataclass
class SearchParameters:
    industry: Optional[str] = None
    location: Optional[str] = None
    keywords: Optional[List[str]] = None
    radius_miles: Optional[int] = 25
    limit: int = 50


class BusinessSearchEngine:
    def __init__(self):
        self.rate_limiter = RateLimiter()
        self.sources = [
            self._search_google_maps,
            self._search_yelp,
            self._search_yellow_pages,
            self._search_bing_places
        ]

    async def find_businesses(self, params: Dict) -> List[Dict]:
        search_params = SearchParameters(**params)
        all_businesses: List[Dict] = []

        tasks = [source(search_params) for source in self.sources]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Source failed: {result}")
                continue
            all_businesses.extend(result)

        unique = self._deduplicate_businesses(all_businesses)
        if search_params.limit:
            unique = unique[:search_params.limit]
        logger.info(f"Discovered {len(unique)} unique businesses")
        return unique

    async def _search_google_maps(self, params: SearchParameters) -> List[Dict]:
        try:
            return [{
                'name': 'Sample Google Maps Biz',
                'source': 'google_maps',
                'address': '123 Main St',
                'phone': '555-0100',
                'website': 'https://sample-google.com',
                'category': params.industry,
                'location': params.location,
                'raw_data': {}
            }]
        except Exception as e:
            logger.error(f"Google Maps search error: {e}")
            return []

    async def _search_yelp(self, params: SearchParameters) -> List[Dict]:
        try:
            return [{
                'name': 'Sample Yelp Biz',
                'source': 'yelp',
                'address': '456 Oak Ave',
                'phone': '555-0200',
                'website': 'https://sample-yelp.com',
                'category': params.industry,
                'location': params.location,
                'raw_data': {}
            }]
        except Exception as e:
            logger.error(f"Yelp search error: {e}")
            return []

    async def _search_yellow_pages(self, params: SearchParameters) -> List[Dict]:
        try:
            return [{
                'name': 'Sample Yellow Pages Biz',
                'source': 'yellow_pages',
                'address': '789 Pine Rd',
                'phone': '555-0300',
                'website': 'https://sample-yp.com',
                'category': params.industry,
                'location': params.location,
                'raw_data': {}
            }]
        except Exception as e:
            logger.error(f"Yellow Pages search error: {e}")
            return []

    async def _search_bing_places(self, params: SearchParameters) -> List[Dict]:
        try:
            return [{
                'name': 'Sample Bing Biz',
                'source': 'bing_places',
                'address': '321 Elm Blvd',
                'phone': '555-0400',
                'website': 'https://sample-bing.com',
                'category': params.industry,
                'location': params.location,
                'raw_data': {}
            }]
        except Exception as e:
            logger.error(f"Bing Places search error: {e}")
            return []

    def _deduplicate_businesses(self, businesses: List[Dict]) -> List[Dict]:
        seen = set()
        unique = []
        for b in businesses:
            key = (b.get('name', '').lower().strip(), b.get('address', '').lower().strip())
            if key not in seen and key[0]:
                seen.add(key)
                unique.append(b)
        return unique