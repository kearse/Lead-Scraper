"""
Export Manager - Handles exporting data to structured folders.
"""
import json
import csv
from pathlib import Path
from datetime import datetime
from typing import List, Dict
from utils.logger import setup_logger

logger = setup_logger(__name__)


class ExportManager:
    def __init__(self):
        self.export_formats = ['json', 'csv', 'txt']

    async def export_profiles(self, profiles: List[Dict], base_path: str, campaign_name: str) -> str:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        export_folder = Path(base_path) / f"{campaign_name}_{timestamp}"
        export_folder.mkdir(parents=True, exist_ok=True)
        logger.info(f"Export folder: {export_folder}")
        await self._create_master_summary(export_folder, profiles)
        for profile in profiles:
            await self._create_business_folder(export_folder, profile)
        await self._create_statistics(export_folder, profiles)
        return str(export_folder)

    async def _create_master_summary(self, export_folder: Path, profiles: List[Dict]):
        summary = {
            'total_businesses': len(profiles),
            'export_date': datetime.utcnow().isoformat(),
            'businesses': []
        }
        for p in profiles:
            summary['businesses'].append({
                'name': p.get('business_name'),
                'address': p.get('address'),
                'phone': p.get('phone'),
                'website': p.get('website'),
                'email': p.get('email'),
                'confidence_score': p.get('confidence_score'),
                'contact_count': len(p.get('contacts', [])),
                'decision_makers_count': len(p.get('decision_makers', []))
            })
        with open(export_folder / "master_summary.json", 'w') as f:
            json.dump(summary, f, indent=2)
        if summary['businesses']:
            with open(export_folder / "master_summary.csv", 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=summary['businesses'][0].keys())
                writer.writeheader()
                writer.writerows(summary['businesses'])

    async def _create_business_folder(self, export_folder: Path, profile: Dict):
        folder_name = self._sanitize_filename(profile.get('business_name', 'unknown'))
        business_folder = export_folder / folder_name
        business_folder.mkdir(exist_ok=True)
        with open(business_folder / "profile.json", 'w') as f:
            json.dump(profile, f, indent=2)

        if profile.get('google_business_profile'):
            gb_folder = business_folder / "google_business"
            gb_folder.mkdir(exist_ok=True)
            with open(gb_folder / "google_business_profile.json", 'w') as f:
                json.dump(profile['google_business_profile'], f, indent=2)

        if profile.get('social_media_profiles'):
            sm_folder = business_folder / "social_media"
            sm_folder.mkdir(exist_ok=True)
            for platform, data in profile['social_media_profiles'].items():
                with open(sm_folder / f"{platform}_profile.json", 'w') as f:
                    json.dump(data, f, indent=2)

        if profile.get('contacts'):
            contacts_folder = business_folder / "contacts"
            contacts_folder.mkdir(exist_ok=True)
            with open(contacts_folder / "all_contacts.json", 'w') as f:
                json.dump(profile['contacts'], f, indent=2)
            self._export_contacts_csv(contacts_folder / "all_contacts.csv", profile['contacts'])
            if profile.get('decision_makers'):
                with open(contacts_folder / "decision_makers.json", 'w') as f:
                    json.dump(profile['decision_makers'], f, indent=2)
                self._export_contacts_csv(contacts_folder / "decision_makers.csv", profile['decision_makers'])

        if profile.get('news_mentions'):
            news_folder = business_folder / "news_mentions"
            news_folder.mkdir(exist_ok=True)
            with open(news_folder / "news_mentions.json", 'w') as f:
                json.dump(profile['news_mentions'], f, indent=2)

        self._create_text_summary(business_folder / "summary.txt", profile)

    def _export_contacts_csv(self, path, contacts: List[Dict]):
        if not contacts:
            return
        keys = set()
        for c in contacts: keys.update(c.keys())
        with open(path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=sorted(keys))
            writer.writeheader()
            writer.writerows(contacts)

    def _create_text_summary(self, path, profile: Dict):
        with open(path, 'w') as f:
            f.write("=" * 60 + "\n")
            f.write("BUSINESS PROFILE SUMMARY\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Business Name: {profile.get('business_name','N/A')}\n")
            f.write(f"Address: {profile.get('address','N/A')}\n")
            f.write(f"Phone: {profile.get('phone','N/A')}\n")
            f.write(f"Website: {profile.get('website','N/A')}\n")
            f.write(f"Email: {profile.get('email','N/A')}\n")
            f.write(f"Industry: {profile.get('industry','N/A')}\n")
            f.write(f"Employee Count: {profile.get('employee_count','N/A')}\n")
            f.write(f"Confidence Score: {profile.get('confidence_score',0):.2f}\n")
            f.write("\nContacts Summary:\n")
            f.write(f"  Total Contacts: {len(profile.get('contacts', []))}\n")
            f.write(f"  Decision Makers: {len(profile.get('decision_makers', []))}\n")
            if profile.get('decision_makers'):
                f.write("  Top Decision Makers:\n")
                for dm in profile['decision_makers'][:5]:
                    f.write(f"    - {dm.get('name','N/A')} ({dm.get('title','N/A')})\n")
            f.write("\nData Sources:\n")
            for source in profile.get('data_sources', []):
                f.write(f"  - {source}\n")
            f.write(f"\nLast Updated: {profile.get('last_updated','N/A')}\n")

    async def _create_statistics(self, export_folder: Path, profiles: List[Dict]):
        stats = {
            'total_businesses': len(profiles),
            'businesses_with_email': sum(1 for p in profiles if p.get('email')),
            'businesses_with_website': sum(1 for p in profiles if p.get('website')),
            'total_contacts': sum(len(p.get('contacts', [])) for p in profiles),
            'total_decision_makers': sum(len(p.get('decision_makers', [])) for p in profiles),
            'average_confidence_score': (sum(p.get('confidence_score', 0) for p in profiles) / len(profiles)) if profiles else 0,
            'data_sources_used': sorted(list(set(source for p in profiles for source in p.get('data_sources', []))))
        }
        with open(export_folder / "statistics.json", 'w') as f:
            json.dump(stats, f, indent=2)

    def _sanitize_filename(self, filename: str) -> str:
        invalid = '<>:"/\\|?*'
        for ch in invalid:
            filename = filename.replace(ch, '_')
        filename = filename.strip().strip('.')
        return filename[:100] or 'unnamed_business'