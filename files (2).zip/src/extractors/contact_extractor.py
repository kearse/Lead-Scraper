"""
Contact Extractor - Finds and normalizes contact information.

Current implementation uses placeholder data; extend with:
- Page crawling of /contact, /about, /team
- Email pattern inference (e.g. first.last@domain)
- External enrichment APIs
"""
import re
import asyncio
from typing import List, Dict, Optional
from nameparser import HumanName
import phonenumbers

from utils.logger import setup_logger

logger = setup_logger(__name__)


class ContactExtractor:
    DECISION_MAKER_TITLES = [
        'CEO', 'CFO', 'CTO', 'COO', 'CMO', 'PRESIDENT', 'VICE PRESIDENT',
        'DIRECTOR', 'MANAGER', 'OWNER', 'FOUNDER', 'PARTNER', 'PRINCIPAL'
    ]

    def __init__(self):
        self.email_pattern = re.compile(r'\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b')
        self.phone_pattern = re.compile(r'[\\+]?[(]?[0-9]{1,3}[)]?[-\\s\\.]?[0-9]{1,4}[-\\s\\.]?[0-9]{1,4}[-\\s\\.]?[0-9]{1,9}')

    async def extract_contacts(
        self,
        business_name: str,
        website: Optional[str] = None,
        social_profiles: Optional[Dict] = None
    ) -> Dict:
        all_contacts: List[Dict] = []
        if website:
            all_contacts.extend(await self._extract_from_website(website))
        if social_profiles:
            all_contacts.extend(await self._extract_from_social(social_profiles))

        deduped = self._deduplicate_contacts(all_contacts)
        enriched = await self._enrich_contacts(deduped)
        decision_makers = self._identify_decision_makers(enriched)
        return {
            'all_contacts': enriched,
            'decision_makers': decision_makers,
            'email_addresses': self._extract_all_emails(enriched),
            'phone_numbers': self._extract_all_phones(enriched)
        }

    async def _extract_from_website(self, website_url: str) -> List[Dict]:
        # Placeholder logic; integrate real crawling later
        await asyncio.sleep(0.02)
        return [{
            'name': 'John Smith',
            'title': 'CEO',
            'email': 'john.smith@example.com',
            'phone': '555-0101',
            'source': 'website'
        }]

    async def _extract_from_social(self, social_profiles: Dict) -> List[Dict]:
        contacts: List[Dict] = []
        await asyncio.sleep(0.01)
        if 'linkedin' in social_profiles:
            contacts.append({
                'name': 'Jane Doe',
                'title': 'VP of Sales',
                'linkedin_url': social_profiles['linkedin'].get('linkedin_url'),
                'source': 'linkedin'
            })
        if 'facebook' in social_profiles and social_profiles['facebook'].get('phone'):
            contacts.append({
                'phone': social_profiles['facebook'].get('phone'),
                'source': 'facebook'
            })
        return contacts

    def _deduplicate_contacts(self, contacts: List[Dict]) -> List[Dict]:
        seen = set()
        unique = []
        for c in contacts:
            key = (c.get('name', '').lower(), c.get('email', '').lower() or c.get('phone', ''))
            if key not in seen:
                seen.add(key)
                unique.append(c)
        return unique

    async def _enrich_contacts(self, contacts: List[Dict]) -> List[Dict]:
        enriched = []
        for c in contacts:
            ec = c.copy()
            if c.get('name'):
                parsed = HumanName(c['name'])
                ec['first_name'] = parsed.first
                ec['last_name'] = parsed.last
                ec['full_name'] = str(parsed)
            if c.get('phone'):
                try:
                    pn = phonenumbers.parse(c['phone'], 'US')
                    if phonenumbers.is_valid_number(pn):
                        ec['phone_formatted'] = phonenumbers.format_number(pn, phonenumbers.PhoneNumberFormat.NATIONAL)
                except Exception:
                    pass
            if c.get('email'):
                ec['email_valid'] = bool(self.email_pattern.match(c['email']))
            enriched.append(ec)
        return enriched

    def _identify_decision_makers(self, contacts: List[Dict]) -> List[Dict]:
        dms = []
        for c in contacts:
            title = (c.get('title') or '').upper()
            for t in self.DECISION_MAKER_TITLES:
                if t in title:
                    c['is_decision_maker'] = True
                    c['decision_maker_score'] = self._calculate_dm_score(c)
                    dms.append(c)
                    break
        dms.sort(key=lambda x: x.get('decision_maker_score', 0), reverse=True)
        return dms

    def _calculate_dm_score(self, contact: Dict) -> float:
        title = (contact.get('title') or '').upper()
        if any(t in title for t in ['CEO', 'CFO', 'CTO', 'COO', 'CMO']): return 1.0
        if 'PRESIDENT' in title: return 0.95
        if 'OWNER' in title or 'FOUNDER' in title: return 0.9
        if 'DIRECTOR' in title: return 0.7
        if 'MANAGER' in title: return 0.6
        return 0.5

    def _extract_all_emails(self, contacts: List[Dict]) -> List[str]:
        return list({c['email'] for c in contacts if c.get('email')})

    def _extract_all_phones(self, contacts: List[Dict]) -> List[str]:
        return list({c['phone'] for c in contacts if c.get('phone')})