"""
Business Intelligence Scraper - Main Entry Point
"""
import asyncio
import argparse
from typing import Dict
from discovery.search_engine import BusinessSearchEngine
from profiles.profile_builder import ProfileBuilder
from export.export_manager import ExportManager
from utils.logger import setup_logger

logger = setup_logger(__name__)


class BusinessIntelligenceScraper:
    """Main orchestrator for the business scraping pipeline"""

    def __init__(self):
        self.search_engine = BusinessSearchEngine()
        self.profile_builder = ProfileBuilder()
        self.export_manager = ExportManager()

    async def run_pipeline(
        self,
        search_params: Dict,
        export_path: str = "exports"
    ) -> str:
        try:
            logger.info(f"Starting business discovery with params: {search_params}")
            businesses = await self.search_engine.find_businesses(search_params)
            logger.info(f"Found {len(businesses)} businesses")

            logger.info("Building business profiles...")
            profiles = []
            for idx, business in enumerate(businesses, 1):
                logger.info(f"Processing business {idx}/{len(businesses)}: {business.get('name', 'Unknown')}")
                profile = await self.profile_builder.build_profile(business)
                profiles.append(profile)

            logger.info("Exporting results...")
            export_result = await self.export_manager.export_profiles(
                profiles,
                export_path,
                search_params.get('campaign_name', 'unnamed_campaign')
            )
            logger.info(f"Export completed: {export_result}")
            return export_result
        except Exception as e:
            logger.exception(f"Pipeline failed: {e}")
            raise


def parse_arguments():
    parser = argparse.ArgumentParser(description='Business Intelligence Scraper')
    parser.add_argument('--industry', type=str, help='Industry (e.g., "restaurants")')
    parser.add_argument('--location', type=str, help='Location (e.g., "New York, NY")')
    parser.add_argument('--keywords', nargs='+', help='Additional keywords')
    parser.add_argument('--limit', type=int, default=50, help='Max businesses')
    parser.add_argument('--export-path', type=str, default='exports', help='Export directory')
    return parser.parse_args()


async def main():
    args = parse_arguments()
    search_params = {
        'industry': args.industry,
        'location': args.location,
        'keywords': args.keywords,
        'limit': args.limit,
        'campaign_name': f"{(args.industry or 'campaign')}_{(args.location or 'anywhere')}".replace(' ', '_')
    }
    scraper = BusinessIntelligenceScraper()
    await scraper.run_pipeline(search_params, args.export_path)


if __name__ == "__main__":
    asyncio.run(main())