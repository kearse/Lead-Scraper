"""
Profile Builder - Aggregates and enriches business data.
"""
import asyncio
from typing import Dict, Optional, List
from datetime import datetime
from dataclasses import dataclass, asdict
from scrapers.google_business import GoogleBusinessScraper
from scrapers.social_media.linkedin import LinkedInScraper
from scrapers.social_media.facebook import FacebookScraper
from extractors.contact_extractor import ContactExtractor
from utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class BusinessProfile:
    business_name: str
    address: str
    phone: str
    website: str
    email: Optional[str] = None
    industry: Optional[str] = None
    description: Optional[str] = None
    founded_year: Optional[int] = None
    employee_count: Optional[str] = None
    revenue_estimate: Optional[str] = None
    google_business_profile: Optional[Dict] = None
    social_media_profiles: Optional[Dict] = None
    directory_listings: Optional[List[Dict]] = None
    news_mentions: Optional[List[Dict]] = None
    contacts: Optional[List[Dict]] = None
    decision_makers: Optional[List[Dict]] = None
    last_updated: Optional[datetime] = None
    data_sources: Optional[List[str]] = None
    confidence_score: Optional[float] = None


class ProfileBuilder:
    def __init__(self):
        self.google_scraper = GoogleBusinessScraper()
        self.linkedin_scraper = LinkedInScraper()
        self.facebook_scraper = FacebookScraper()
        self.contact_extractor = ContactExtractor()

    async def build_profile(self, business_info: Dict) -> Dict:
        logger.info(f"Building profile: {business_info.get('name')}")
        profile = BusinessProfile(
            business_name=business_info.get('name', ''),
            address=business_info.get('address', ''),
            phone=business_info.get('phone', ''),
            website=business_info.get('website', ''),
            industry=business_info.get('category', ''),
            last_updated=datetime.utcnow(),
            data_sources=[business_info.get('source', 'unknown')]
        )
        tasks = [
            self._enrich_google_business(profile, business_info),
            self._enrich_social_media(profile, business_info),
            self._enrich_contacts(profile, business_info),
            self._enrich_news_mentions(profile, business_info)
        ]
        await asyncio.gather(*tasks, return_exceptions=True)
        profile.confidence_score = self._calculate_confidence(profile)
        return asdict(profile)

    async def _enrich_google_business(self, profile: BusinessProfile, business_info: Dict):
        try:
            data = await self.google_scraper.scrape(business_info.get('name'), business_info.get('location'))
            if data:
                profile.google_business_profile = data
                profile.data_sources.append('google_business')
                profile.website = profile.website or data.get('website', '')
                profile.email = profile.email or data.get('email')
                if data.get('description'):
                    profile.description = data['description']
        except Exception as e:
            logger.error(f"Google enrich failed: {e}")

    async def _enrich_social_media(self, profile: BusinessProfile, business_info: Dict):
        social = {}
        try:
            li = await self.linkedin_scraper.scrape(business_info.get('name'))
            if li:
                social['linkedin'] = li
                if li.get('employee_count'):
                    profile.employee_count = li['employee_count']
            fb = await self.facebook_scraper.scrape(business_info.get('name'))
            if fb:
                social['facebook'] = fb
            if social:
                profile.social_media_profiles = social
                profile.data_sources.append('social_media')
        except Exception as e:
            logger.error(f"Social enrich failed: {e}")

    async def _enrich_contacts(self, profile: BusinessProfile, business_info: Dict):
        try:
            contacts = await self.contact_extractor.extract_contacts(
                business_name=business_info.get('name'),
                website=business_info.get('website'),
                social_profiles=profile.social_media_profiles
            )
            if contacts:
                profile.contacts = contacts.get('all_contacts', [])
                profile.decision_makers = contacts.get('decision_makers', [])
                profile.data_sources.append('contact_extraction')
        except Exception as e:
            logger.error(f"Contact enrich failed: {e}")

    async def _enrich_news_mentions(self, profile: BusinessProfile, business_info: Dict):
        # Placeholder for future news integration
        return

    def _calculate_confidence(self, profile: BusinessProfile) -> float:
        score = 0.0
        max_score = 10.0
        if profile.business_name: score += 1
        if profile.address: score += 1
        if profile.phone: score += 1
        if profile.website: score += 1
        if profile.email: score += 1
        if profile.google_business_profile: score += 1.5
        if profile.social_media_profiles: score += 1.5
        if profile.contacts: score += 1
        if profile.decision_makers: score += 1
        return min(score / max_score, 1.0)