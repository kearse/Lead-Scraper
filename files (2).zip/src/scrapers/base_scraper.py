"""
Base scraper interface / common helpers (placeholder for future expansion).
"""
from abc import ABC, abstractmethod


class BaseScraper(ABC):
    @abstractmethod
    async def scrape(self, *args, **kwargs):
        raise NotImplementedError