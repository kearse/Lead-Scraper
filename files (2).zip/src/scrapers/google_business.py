"""
Google Business scraper (placeholder).
Real implementation should call Google Places API and map fields.
"""
import asyncio
from typing import Dict, Optional


class GoogleBusinessScraper:
    async def scrape(self, business_name: str, location: Optional[str]) -> Dict:
        # Simulated latency
        await asyncio.sleep(0.05)
        return {
            'name': business_name,
            'location': location,
            'website': None,
            'email': None,
            'description': f"Placeholder description for {business_name}",
            'rating': None,
            'reviews_count': None
        }