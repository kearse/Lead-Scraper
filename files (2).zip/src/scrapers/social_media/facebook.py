"""
Facebook Page scraper stub.
"""
import asyncio
from typing import Dict, Optional


class FacebookScraper:
    async def scrape(self, business_name: str) -> Optional[Dict]:
        await asyncio.sleep(0.03)
        return {
            'page_name': business_name,
            'facebook_url': f"https://www.facebook.com/{business_name.replace(' ', '').lower()}",
            'phone': None,
            'about': f"Facebook placeholder page for {business_name}"
        }