"""
LinkedIn scraper stub.
WARNING: Direct scraping of LinkedIn may violate their Terms of Service.
"""
import asyncio
from typing import Dict, Optional


class LinkedInScraper:
    async def scrape(self, business_name: str) -> Optional[Dict]:
        await asyncio.sleep(0.05)
        return {
            'company': business_name,
            'employee_count': '51-200',
            'linkedin_url': f"https://www.linkedin.com/company/{business_name.replace(' ', '').lower()}",
            'about': f"LinkedIn placeholder profile for {business_name}"
        }