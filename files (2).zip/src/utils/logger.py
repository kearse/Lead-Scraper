from loguru import logger
import os
from typing import Optional


def setup_logger(name: Optional[str] = None):
    # Configure once
    if not logger._core.handlers:
        log_level = os.getenv("LOG_LEVEL", "INFO")
        logger.remove()
        logger.add(lambda msg: print(msg, end=""), level=log_level)
    return logger