"""
Simple placeholder rate limiter interface.
Extend with token bucket / Redis-based limiter as needed.
"""
import asyncio
from typing import Optional


class RateLimiter:
    def __init__(self, min_delay: float = 0.1):
        self.min_delay = min_delay
        self._last_call: Optional[float] = None

    async def wait(self):
        await asyncio.sleep(self.min_delay)